# netvan
Small and easy to use feed-forward ANN library
